-- Führe dieses SQL-Skript im Supabase SQL Editor aus, um die Voting-Dauer Logik zu aktualisieren.

CREATE OR REPLACE FUNCTION public.finish_fixture_and_open_voting(p_fixture_id uuid, p_voting_minutes integer DEFAULT NULL)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_fixture record;
    v_voting_minutes integer;
    v_open_at timestamptz;
    v_close_at timestamptz;
    v_match_type text;
BEGIN
    SELECT * INTO v_fixture
    FROM public.fixtures
    WHERE id = p_fixture_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Fixture % not found', p_fixture_id;
    END IF;

    v_match_type := v_fixture.match_type;

    IF v_match_type = 'reserve' THEN
        v_voting_minutes := 180;
    ELSIF v_match_type = 'kampfmannschaft' THEN
        v_voting_minutes := 60;
    ELSE
        v_voting_minutes := 60;
    END IF;

    v_open_at := now();
    v_close_at := now() + (v_voting_minutes || ' minutes')::interval;

    UPDATE public.fixtures
    SET status = 'finished',
        match_phase = 'full_time',
        voting_open_at = v_open_at,
        voting_close_at = v_close_at,
        results_processed_at = NULL
    WHERE id = p_fixture_id;

    RETURN json_build_object(
        'match_type', v_match_type,
        'voting_minutes', v_voting_minutes,
        'voting_open_at', v_open_at,
        'voting_close_at', v_close_at,
        'status', 'finished'
    );
END;
$$;

-- RPC Update for submit_player_vote to support 'neutral' votes
CREATE OR REPLACE FUNCTION public.submit_player_vote(
    p_fixture_id uuid,
    p_player_id uuid,
    p_vote text,
    p_bypass_checkin boolean DEFAULT false
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id uuid;
    v_status text;
    v_voting_open_at timestamptz;
    v_voting_close_at timestamptz;
    v_has_checked_in boolean;
BEGIN
    -- 1. Accept 'up', 'down', and 'neutral'
    IF p_vote NOT IN ('up', 'down', 'neutral') THEN
        RETURN jsonb_build_object('success', false, 'error', 'Invalid vote type. Must be up, down, or neutral.');
    END IF;

    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
    END IF;

    -- 2. Verify fixture and voting window
    SELECT status, voting_open_at, voting_close_at 
    INTO v_status, v_voting_open_at, v_voting_close_at
    FROM public.fixtures
    WHERE id = p_fixture_id;

    IF v_status != 'finished' THEN
        RETURN jsonb_build_object('success', false, 'error', 'Match is not finished');
    END IF;

    IF now() < v_voting_open_at THEN
        RETURN jsonb_build_object('success', false, 'error', 'Voting has not started');
    END IF;

    IF now() > v_voting_close_at THEN
        RETURN jsonb_build_object('success', false, 'error', 'Voting has closed');
    END IF;

    -- 3. Check GPS check-in requirement, if not bypassed
    IF NOT p_bypass_checkin THEN
        SELECT EXISTS (
            SELECT 1 FROM public.match_checkins
            WHERE fixture_id = p_fixture_id AND user_id = v_user_id
        ) INTO v_has_checked_in;
        IF NOT v_has_checked_in THEN
            RETURN jsonb_build_object('success', false, 'error', 'Must check in to match to vote');
        END IF;
    END IF;

    -- 4. Try updating the column vote_type. If the column is named 'vote', update that instead.
    BEGIN
        INSERT INTO public.player_votes (fixture_id, player_id, user_id, vote_type)
        VALUES (p_fixture_id, p_player_id, v_user_id, p_vote)
        ON CONFLICT (fixture_id, player_id, user_id) 
        DO UPDATE SET vote_type = EXCLUDED.vote_type, updated_at = now();
    EXCEPTION WHEN OTHERS THEN
        INSERT INTO public.player_votes (fixture_id, player_id, user_id, vote)
        VALUES (p_fixture_id, p_player_id, v_user_id, p_vote)
        ON CONFLICT (fixture_id, player_id, user_id) 
        DO UPDATE SET vote = EXCLUDED.vote, updated_at = now();
    END;

    RETURN jsonb_build_object('success', true);
END;
$$;

NOTIFY pgrst, 'reload schema';

