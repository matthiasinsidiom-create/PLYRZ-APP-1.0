import React, { useState, useEffect, useCallback, memo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  Users, 
  Trophy, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Shield, 
  ChevronRight,
  Plus,
  Minus,
  Trash2,
  Star,
  Check,
  X,
  Calendar,
  MapPin,
  Settings,
  Zap,
  Timer,
  Search,
  ChevronLeft
} from 'lucide-react';
import { supabaseService } from '../../services/supabaseService';
import { getPositionShort } from '../../lib/positions';
import { Fixture, FixtureLineup, MatchEvent } from '../../types';

interface LineupEntryState {
  player_id: string;
  jersey_number: string;
  lineup_role: 'starter' | 'sub';
}

const AdminMatchControl: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const [fixture, setFixture] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState({ checkins: 0, votes: 0 });
  
  // Lineup State
  const [homePlayers, setHomePlayers] = useState<any[]>([]);
  const [awayPlayers, setAwayPlayers] = useState<any[]>([]);
  const [lineup, setLineup] = useState<{ home: LineupEntryState[], away: LineupEntryState[] }>({ home: [], away: [] });
  
  // Events State
  const [events, setEvents] = useState<any[]>([]);
  const [showConfirmProcess, setShowConfirmProcess] = useState(false);
  const [isAddingOpponentGoal, setIsAddingOpponentGoal] = useState<'home' | 'away' | null>(null);
  const [opponentJerseyNumber, setOpponentJerseyNumber] = useState('');
  const [opponentMinute, setOpponentMinute] = useState('');
  
  // UI State
  const [activeSection, setActiveSection] = useState<'live' | 'lineups' | 'events' | 'votes' | 'processing'>(() => {
    // Default to lineups if not live, or events/live if live
    return 'lineups';
  });
  const [showLiveGoalModal, setShowLiveGoalModal] = useState(false);
  const [liveGoalTeam, setLiveGoalTeam] = useState<'home' | 'away' | null>(null);
  const [liveGoalFormType, setLiveGoalFormType] = useState<'player' | 'opponent' | null>(null);
  const [playerSearchQuery, setPlayerSearchQuery] = useState('');
  const [statusModal, setStatusModal] = useState<{ isOpen: boolean; title: string; message: string; type: 'success' | 'error' }>({
    isOpen: false,
    title: '',
    message: '',
    type: 'success'
  });

  useEffect(() => {
    if (id) {
      loadMatchData();
    }
  }, [id]);

  const loadMatchData = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const fixtures = await supabaseService.getFixtures();
      const currentFixture = fixtures.find(f => f.id === id);
      
      if (!currentFixture) {
        navigate('/admin/fixtures');
        return;
      }
      
      setFixture(currentFixture);
      
      // Load Lineups
      const currentLineup = await supabaseService.getFixtureLineup(id);
      
      // Load Players for both clubs
      const homeClubId = currentFixture.home_team?.club_id;
      const awayClubId = currentFixture.away_team?.club_id;
      
      if (homeClubId && awayClubId) {
        const allPlayers = await supabaseService.getPlayersByClubs([homeClubId, awayClubId]);
        
        const homeClubPlayers = allPlayers.filter(p => (p as any).teams?.club_id === homeClubId);
        const awayClubPlayers = allPlayers.filter(p => (p as any).teams?.club_id === awayClubId);
        
        setHomePlayers(homeClubPlayers);
        setAwayPlayers(awayClubPlayers);
        
        const homeEntries = currentLineup
          .filter(l => l.team_id === currentFixture.home_team_id)
          .map(l => {
            const player = homeClubPlayers.find(p => p.id === l.player_id);
            return {
              player_id: l.player_id,
              jersey_number: (l.jersey_number || player?.jersey_number || '').toString(),
              lineup_role: (l.lineup_role as 'starter' | 'sub') || 'starter'
            };
          });
        const awayEntries = currentLineup
          .filter(l => l.team_id === currentFixture.away_team_id)
          .map(l => {
            const player = awayClubPlayers.find(p => p.id === l.player_id);
            return {
              player_id: l.player_id,
              jersey_number: (l.jersey_number || player?.jersey_number || '').toString(),
              lineup_role: (l.lineup_role as 'starter' | 'sub') || 'starter'
            };
          });
        
        setLineup({ home: homeEntries, away: awayEntries });
      }
      
      // Load Events
      const matchEvents = await supabaseService.getMatchEvents(id);
      setEvents(matchEvents);

      // Load Stats
      const matchStats = await supabaseService.getFixtureStats(id);
      setStats(matchStats);
      
    } catch (err) {
      console.error('Error loading match data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateFixture = async (updates: Partial<Fixture>) => {
    if (!id) return;
    setSaving(true);
    try {
      const updated = await supabaseService.updateFixture(id, updates);
      setFixture(updated);
      setStatusModal({
        isOpen: true,
        title: 'Success',
        message: 'Fixture updated successfully.',
        type: 'success'
      });
    } catch (err) {
      console.error('Error updating fixture:', err);
      setStatusModal({
        isOpen: true,
        title: 'Error',
        message: 'Failed to update fixture.',
        type: 'error'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleSaveLineup = async () => {
    if (!id || !fixture) return;
    setSaving(true);
    try {
      const lineupData = [
        ...lineup.home.map(e => ({ 
          fixture_id: id, 
          team_id: fixture.home_team_id, 
          player_id: e.player_id,
          jersey_number: e.jersey_number ? parseInt(e.jersey_number) : null,
          lineup_role: e.lineup_role
        })),
        ...lineup.away.map(e => ({ 
          fixture_id: id, 
          team_id: fixture.away_team_id, 
          player_id: e.player_id,
          jersey_number: e.jersey_number ? parseInt(e.jersey_number) : null,
          lineup_role: e.lineup_role
        }))
      ];
      await supabaseService.updateFixtureLineup(id, lineupData);
      setStatusModal({
        isOpen: true,
        title: 'Success',
        message: 'Lineup saved successfully.',
        type: 'success'
      });
    } catch (err) {
      console.error('Error saving lineup:', err);
      setStatusModal({
        isOpen: true,
        title: 'Error',
        message: 'Failed to save lineup.',
        type: 'error'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleAddEvent = async (playerId: string, eventType: any) => {
    if (!id || !fixture) return;
    
    const isHome = lineup.home.some(l => l.player_id === playerId);
    const teamId = isHome ? fixture.home_team_id : fixture.away_team_id;

    const tempId = `temp-${Math.random().toString(36).substring(7)}`;
    const newEvent = {
      id: tempId,
      fixture_id: id,
      team_id: teamId,
      player_id: playerId,
      event_type: eventType,
      created_at: new Date().toISOString()
    };
    
    setEvents(prev => [...prev, newEvent]);
    
    // Update score if goal
    if (eventType === 'goal') {
      const scoreField = isHome ? 'home_score' : 'away_score';
      const currentScore = fixture[scoreField] || 0;
      const newScore = currentScore + 1;
      
      setFixture(prev => ({ ...prev, [scoreField]: newScore }));
      try {
        await supabaseService.updateFixture(id, { [scoreField]: newScore });
      } catch (err) {
        console.error('Error updating score:', err);
      }
    }
    
    try {
      const created = await supabaseService.createMatchEvent({
        fixture_id: id,
        team_id: teamId,
        player_id: playerId,
        event_type: eventType
      });
      setEvents(prev => prev.map(e => e.id === tempId ? created : e));
    } catch (err) {
      console.error('Error adding event:', err);
      setEvents(prev => prev.filter(e => e.id !== tempId));
    }
  };

  const handleRemoveEvent = async (playerId: string, eventType: string) => {
    if (!id) return;
    
    const eventToRemove = [...events].reverse().find(e => e.player_id === playerId && e.event_type === eventType);
    if (!eventToRemove) return;
    
    const originalEvents = [...events];
    setEvents(prev => prev.filter(e => e.id !== eventToRemove.id));
    
    // Update score if goal or opponent_goal
    if (eventType === 'goal' || eventType === 'opponent_goal') {
      const isHome = eventToRemove.team_id === fixture.home_team_id;
      const scoreField = isHome ? 'home_score' : 'away_score';
      const currentScore = fixture[scoreField] || 0;
      const newScore = Math.max(0, currentScore - 1);
      
      setFixture(prev => ({ ...prev, [scoreField]: newScore }));
      try {
        await supabaseService.updateFixture(id, { [scoreField]: newScore });
      } catch (err) {
        console.error('Error updating score:', err);
      }
    }
    
    try {
      if (!eventToRemove.id.startsWith('temp-')) {
        await supabaseService.deleteMatchEvent(eventToRemove.id);
      }
    } catch (err) {
      console.error('Error removing event:', err);
      setEvents(originalEvents);
    }
  };

  const handleProcessResults = async () => {
    if (!id) return;
    setSaving(true);
    try {
      const result = await supabaseService.processFixtureRatings(id);
      setStatusModal({
        isOpen: true,
        title: 'Processing Complete',
        message: result.message || 'Ratings processed successfully.',
        type: 'success'
      });
      await loadMatchData();
    } catch (err: any) {
      console.error('Error processing ratings:', err);
      setStatusModal({
        isOpen: true,
        title: 'Processing Failed',
        message: err.message || 'Failed to process ratings.',
        type: 'error'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleRemoveOpponentGoal = async (teamType: 'home' | 'away', eventId: string) => {
    if (!id || !fixture) return;
    
    const eventToRemove = events.find(e => e.id === eventId);
    if (!eventToRemove) return;

    const originalEvents = [...events];
    setEvents(prev => prev.filter(e => e.id !== eventId));

    // Update score
    const scoreField = teamType === 'home' ? 'home_score' : 'away_score';
    const currentScore = fixture[scoreField] || 0;
    const newScore = Math.max(0, currentScore - 1);
    
    setFixture(prev => ({ ...prev, [scoreField]: newScore }));
    
    try {
      if (!eventId.startsWith('temp-')) {
        await supabaseService.deleteMatchEvent(eventId);
      }
      await supabaseService.updateFixture(id, { [scoreField]: newScore });
    } catch (err) {
      console.error('Error removing opponent goal:', err);
      setEvents(originalEvents);
      setFixture(prev => ({ ...prev, [scoreField]: currentScore }));
    }
  };

  const handleAddOpponentGoal = async (teamType: 'home' | 'away') => {
    if (!id || !fixture) return;
    
    const teamId = teamType === 'home' ? fixture.home_team_id : fixture.away_team_id;
    const jersey = opponentJerseyNumber;
    const minute = parseInt(opponentMinute) || null;

    const tempId = `temp-${Math.random().toString(36).substring(7)}`;
    const newEvent = {
      id: tempId,
      fixture_id: id,
      team_id: teamId,
      player_id: null,
      event_type: 'opponent_goal',
      opponent_jersey_number: jersey,
      minute: minute,
      created_at: new Date().toISOString()
    };
    
    setEvents(prev => [...prev, newEvent]);

    // Update score
    const scoreField = teamType === 'home' ? 'home_score' : 'away_score';
    const currentScore = fixture[scoreField] || 0;
    const newScore = currentScore + 1;
    setFixture(prev => ({ ...prev, [scoreField]: newScore }));

    try {
      await supabaseService.updateFixture(id, { [scoreField]: newScore });
      const created = await supabaseService.createMatchEvent({
        fixture_id: id,
        team_id: teamId,
        event_type: 'opponent_goal',
        opponent_jersey_number: jersey,
        minute: minute
      });
      setEvents(prev => prev.map(e => e.id === tempId ? created : e));
      
      // Reset state
      setIsAddingOpponentGoal(null);
      setOpponentJerseyNumber('');
      setOpponentMinute('');
    } catch (err) {
      console.error('Error adding opponent goal:', err);
      setEvents(prev => prev.filter(e => e.id !== tempId));
      setFixture(prev => ({ ...prev, [scoreField]: currentScore }));
    }
  };

  const togglePlayer = useCallback((team: 'home' | 'away', playerId: string) => {
    setLineup(prev => {
      const current = prev[team];
      const isAlreadyIn = current.some(e => e.player_id === playerId);

      if (isAlreadyIn) {
        return { ...prev, [team]: current.filter(e => e.player_id !== playerId) };
      } else {
        const starterCount = current.filter(e => e.lineup_role === 'starter').length;
        const playerPool = team === 'home' ? homePlayers : awayPlayers;
        const player = playerPool.find(p => p.id === playerId);
        const newEntry: LineupEntryState = {
          player_id: playerId,
          jersey_number: (player?.jersey_number ?? '').toString(),
          lineup_role: starterCount < 11 ? 'starter' : 'sub'
        };
        return { ...prev, [team]: [...current, newEntry] };
      }
    });
  }, [homePlayers, awayPlayers]);

  const updatePlayerDetail = useCallback((team: 'home' | 'away', playerId: string, updates: Partial<LineupEntryState>) => {
    setLineup(prev => ({
      ...prev,
      [team]: prev[team].map(e => e.player_id === playerId ? { ...e, ...updates } : e)
    }));
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  if (!fixture) return null;

  const isProcessed = !!fixture.results_processed_at;
  const hasHomeLineup = lineup.home.length >= 11;
  const hasAwayLineup = lineup.away.length >= 11;
  const hasScore = fixture.home_score !== null && fixture.away_score !== null;
  const hasEvents = events.length > 0;
  const canProcess = hasHomeLineup && hasAwayLineup && hasScore && !isProcessed;

  return (
    <div className="min-h-screen bg-transparent p-4 pb-24 text-white font-sans">
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <button 
            onClick={() => navigate('/admin/fixtures')}
            className="p-2 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl"
          >
            <ArrowLeft className="w-5 h-5 text-zinc-400" />
          </button>
          <div className="text-center">
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{fixture.leagues?.name}</p>
            <h1 className="text-xl font-black italic uppercase tracking-tighter">MATCH CONTROL</h1>
          </div>
          <button 
            onClick={() => loadMatchData()}
            className="p-2 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl"
          >
            <Clock className="w-5 h-5 text-zinc-400" />
          </button>
        </div>

        {/* Fixture Card */}
        <div className="bg-black/40 backdrop-blur-md border border-white/10 rounded-3xl p-6 space-y-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1 text-center space-y-2">
              <div className="w-12 h-12 bg-zinc-800 rounded-2xl mx-auto flex items-center justify-center">
                <Shield className="w-6 h-6 text-emerald-500" />
              </div>
              <div>
                <p className="font-bold text-sm uppercase italic tracking-tight">{fixture.home_team?.clubs?.name}</p>
                <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{fixture.home_team?.name}</p>
              </div>
            </div>

            <div className="flex flex-col items-center gap-2">
              <div className="flex items-center gap-3">
                <input 
                  type="number"
                  value={fixture.home_score ?? ''}
                  onChange={(e) => setFixture({ ...fixture, home_score: e.target.value === '' ? null : parseInt(e.target.value) })}
                  onBlur={() => handleUpdateFixture({ home_score: fixture.home_score })}
                  className="w-12 h-12 bg-zinc-900 border border-zinc-800 rounded-xl text-center text-xl font-black focus:border-emerald-500 outline-none"
                  placeholder="-"
                />
                <span className="text-zinc-700 font-black">:</span>
                <input 
                  type="number"
                  value={fixture.away_score ?? ''}
                  onChange={(e) => setFixture({ ...fixture, away_score: e.target.value === '' ? null : parseInt(e.target.value) })}
                  onBlur={() => handleUpdateFixture({ away_score: fixture.away_score })}
                  className="w-12 h-12 bg-zinc-900 border border-zinc-800 rounded-xl text-center text-xl font-black focus:border-emerald-500 outline-none"
                  placeholder="-"
                />
              </div>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-widest border ${
                fixture.status === 'live' ? 'bg-red-500/10 text-red-500 border-red-500/20' :
                fixture.status === 'finished' ? 'bg-zinc-800 text-zinc-500 border-zinc-700' :
                'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
              }`}>
                {fixture.status}
              </span>
            </div>

            <div className="flex-1 text-center space-y-2">
              <div className="w-12 h-12 bg-zinc-800 rounded-2xl mx-auto flex items-center justify-center">
                <Shield className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <p className="font-bold text-sm uppercase italic tracking-tight">{fixture.away_team?.clubs?.name}</p>
                <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{fixture.away_team?.name}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-zinc-800/50">
            <div className="flex items-center gap-2 text-zinc-500">
              <Calendar className="w-4 h-4" />
              <span className="text-xs font-bold">{new Date(fixture.kickoff_at).toLocaleDateString([], { day: '2-digit', month: 'short' })}</span>
            </div>
            <div className="flex items-center gap-2 text-zinc-500 justify-end">
              <Clock className="w-4 h-4" />
              <span className="text-xs font-bold">{new Date(fixture.kickoff_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          </div>
        </div>

        {/* Live Match Screen - Primary Workflow Controls */}
        {fixture.status === 'live' && (
          <div className="bg-black/40 backdrop-blur-md border border-amber-500/30 rounded-3xl p-6 shadow-[0_0_30px_rgba(245,158,11,0.1)]">
            {console.log('MatchControl: Rendering Live Match Control area')}
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 bg-amber-500 text-black rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/20">
                <Zap className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-black italic uppercase tracking-tighter leading-none">Live Match Control</h2>
                <p className="text-[10px] font-bold text-amber-500/60 uppercase tracking-widest mt-1">Primäre Live-Aktionen</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Tor Eigenes Team - Player selection */}
              <button 
                onClick={() => {
                  console.log('Live own-team goal button clicked');
                  setLiveGoalTeam('home');
                  setLiveGoalFormType('player');
                  setShowLiveGoalModal(true);
                }}
                className="p-6 bg-emerald-500 hover:bg-emerald-400 text-black rounded-3xl flex items-center gap-4 transition-all active:scale-[0.98] shadow-xl shadow-emerald-500/10 group overflow-hidden relative"
              >
                 <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:scale-110 transition-transform">
                   <Trophy className="w-16 h-16 -mr-4 -mt-4" />
                 </div>
                 <div className="w-12 h-12 bg-black/10 rounded-2xl flex items-center justify-center shrink-0">
                   <Trophy className="w-6 h-6" />
                 </div>
                 <div className="text-left">
                   <p className="text-sm font-black uppercase italic tracking-tighter">Tor {fixture.home_team?.clubs?.name || 'Eigenes Team'}</p>
                   <p className="text-[10px] font-bold opacity-60 uppercase tracking-widest">Spieler Auswahl</p>
                 </div>
              </button>

              {/* Tor Gegner - Lightweight selection */}
              <button 
                onClick={() => {
                  console.log('Opponent goal button clicked');
                  console.log('Opening Lightweight Opponent Goal form');
                  setLiveGoalTeam('away');
                  setLiveGoalFormType('opponent');
                  setShowLiveGoalModal(true);
                  setIsAddingOpponentGoal('away');
                }}
                className="p-6 bg-zinc-900 border border-white/10 text-white rounded-3xl flex items-center gap-4 transition-all active:scale-[0.98] hover:bg-zinc-800 shadow-xl group overflow-hidden relative"
              >
                 <div className="absolute top-0 right-0 p-2 opacity-5 group-hover:scale-110 transition-transform">
                   <Plus className="w-16 h-16 -mr-4 -mt-4 text-emerald-500" />
                 </div>
                 <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center shrink-0">
                   <Plus className="w-6 h-6 text-emerald-500" />
                 </div>
                 <div className="text-left">
                   <p className="text-sm font-black uppercase italic tracking-tighter">Tor Gegner</p>
                   <p className="text-[10px] font-bold opacity-40 uppercase tracking-widest">Lightweight Log</p>
                 </div>
              </button>
            </div>

            {events.length > 0 && (
              <div className="mt-6 pt-6 border-t border-white/5">
                <div className="flex items-center justify-between mb-3 px-1">
                  <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest">Recent Events</span>
                  <button 
                    onClick={() => setActiveSection('events')}
                    className="text-[8px] font-black text-emerald-500 uppercase tracking-widest"
                  >
                    View All
                  </button>
                </div>
                <div className="space-y-1.5 text-left">
                  {events.slice(-3).reverse().map(event => (
                    <div key={event.id} className="flex items-center justify-between p-2.5 bg-zinc-900/50 rounded-xl border border-white/5">
                      <div className="flex items-center gap-2 text-left">
                        <span className="text-[10px]">{event.event_type === 'goal' || event.event_type === 'opponent_goal' ? '⚽' : '🎫'}</span>
                        <span className="text-[9px] font-black italic text-zinc-500">{event.minute || '??'}'</span>
                        <span className="text-[10px] font-black italic uppercase text-zinc-300">
                          {event.event_type === 'opponent_goal' ? `Tor Gegner #${event.opponent_jersey_number || '?'}` : (homePlayers.find(p => p.id === event.player_id)?.full_name || awayPlayers.find(p => p.id === event.player_id)?.full_name || 'Event')}
                        </span>
                      </div>
                      <button 
                        onClick={() => event.event_type === 'opponent_goal' ? handleRemoveOpponentGoal(event.team_id === fixture.home_team_id ? 'home' : 'away', event.id) : handleRemoveEvent(event.player_id, event.event_type)}
                        className="p-1 hover:bg-red-500/10 rounded group transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-zinc-700 group-hover:text-red-500" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Hub Sections */}
        <div className="grid grid-cols-1 gap-4">
          {/* 1. Lineups Hub */}
          <HubCard 
            title="Lineups" 
            icon={<Users className="w-5 h-5" />}
            status={hasHomeLineup && hasAwayLineup ? 'complete' : 'pending'}
            isActive={activeSection === 'lineups'}
            onClick={() => setActiveSection('lineups')}
          >
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <TeamLineupSelector 
                  teamName={fixture.home_team?.name}
                  players={homePlayers}
                  selectedLineup={lineup.home}
                  onToggle={(id) => togglePlayer('home', id)}
                  onUpdateDetail={(id, updates) => updatePlayerDetail('home', id, updates)}
                  color="emerald"
                />
                <TeamLineupSelector 
                  teamName={fixture.away_team?.name}
                  players={awayPlayers}
                  selectedLineup={lineup.away}
                  onToggle={(id) => togglePlayer('away', id)}
                  onUpdateDetail={(id, updates) => updatePlayerDetail('away', id, updates)}
                  color="blue"
                />
              </div>
              <button 
                onClick={handleSaveLineup}
                disabled={saving}
                className="w-full bg-emerald-500 text-black font-black py-4 rounded-2xl flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                SAVE LINEUPS
              </button>
            </div>
          </HubCard>

          {/* 2. Match Events Hub */}
          <HubCard 
            title="Match Events" 
            icon={<Trophy className="w-5 h-5" />}
            status={hasEvents ? 'complete' : 'pending'}
            isActive={activeSection === 'events'}
            onClick={() => setActiveSection('events')}
          >
            <div className="space-y-8">
              {/* Home Team */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 px-1">
                  <div className="w-1 h-3 bg-emerald-500 rounded-full" />
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">{fixture.home_team?.name}</h4>
                </div>
                <div className="space-y-2">
                  {lineup.home.map(entry => {
                    const player = homePlayers.find(p => p.id === entry.player_id);
                    if (!player) return null;
                    return (
                      <PlayerEventRow 
                        key={player.id}
                        player={player}
                        events={events.filter(e => e.player_id === player.id)}
                        onAdd={handleAddEvent}
                        onRemove={handleRemoveEvent}
                      />
                    );
                  })}

                  {/* Opponent Goal Actions for Home */}
                  <OpponentGoalSection 
                    teamType="home"
                    isAdding={isAddingOpponentGoal === 'home'}
                    jerseyNumber={opponentJerseyNumber}
                    minute={opponentMinute}
                    events={events.filter(e => e.event_type === 'opponent_goal' && e.team_id === fixture.home_team_id)}
                    onStartAdd={() => setIsAddingOpponentGoal('home')}
                    onCancel={() => setIsAddingOpponentGoal(null)}
                    onJerseyChange={setOpponentJerseyNumber}
                    onMinuteChange={setOpponentMinute}
                    onAdd={() => handleAddOpponentGoal('home')}
                    onRemove={(eventId) => handleRemoveOpponentGoal('home', eventId)}
                  />
                </div>
              </div>

              {/* Away Team */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 px-1">
                  <div className="w-1 h-3 bg-blue-500 rounded-full" />
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">{fixture.away_team?.name}</h4>
                </div>
                <div className="space-y-2">
                  {lineup.away.map(entry => {
                    const player = awayPlayers.find(p => p.id === entry.player_id);
                    if (!player) return null;
                    return (
                      <PlayerEventRow 
                        key={player.id}
                        player={player}
                        events={events.filter(e => e.player_id === player.id)}
                        onAdd={handleAddEvent}
                        onRemove={handleRemoveEvent}
                      />
                    );
                  })}
                  
                  {/* Opponent Goal Actions for Away */}
                  <OpponentGoalSection 
                    teamType="away"
                    isAdding={isAddingOpponentGoal === 'away'}
                    jerseyNumber={opponentJerseyNumber}
                    minute={opponentMinute}
                    events={events.filter(e => e.event_type === 'opponent_goal' && e.team_id === fixture.away_team_id)}
                    onStartAdd={() => setIsAddingOpponentGoal('away')}
                    onCancel={() => setIsAddingOpponentGoal(null)}
                    onJerseyChange={setOpponentJerseyNumber}
                    onMinuteChange={setOpponentMinute}
                    onAdd={() => handleAddOpponentGoal('away')}
                    onRemove={(eventId) => handleRemoveOpponentGoal('away', eventId)}
                  />
                </div>
              </div>
            </div>
          </HubCard>

          {/* 3. Votes & Status Hub */}
          <HubCard 
            title="Votes & Match Status" 
            icon={<Star className="w-5 h-5" />}
            status={fixture.status === 'finished' ? 'complete' : 'pending'}
            isActive={activeSection === 'votes'}
            onClick={() => setActiveSection('votes')}
          >
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800 space-y-1">
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Match Status</p>
                  <select 
                    value={fixture.status}
                    onChange={(e) => handleUpdateFixture({ status: e.target.value as any })}
                    className="w-full bg-transparent font-black italic uppercase tracking-tighter text-lg outline-none"
                  >
                    <option value="upcoming">Upcoming</option>
                    <option value="live">Live</option>
                    <option value="finished">Finished</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
                <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800 space-y-1">
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Voting Window</p>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-white">
                      {fixture.voting_open_at ? new Date(fixture.voting_open_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Not set'}
                    </span>
                    <span className="text-[10px] text-zinc-600">to</span>
                    <span className="text-xs font-bold text-white">
                      {fixture.voting_close_at ? new Date(fixture.voting_close_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Not set'}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-xs font-black uppercase tracking-widest text-emerald-500">Voting Activity</h4>
                  <span className="px-2 py-0.5 bg-emerald-500 text-black text-[10px] font-black rounded-full">LIVE</span>
                </div>
                <div className="flex items-center justify-around text-center">
                  <div>
                    <p className="text-2xl font-black italic tracking-tighter">{stats.checkins}</p>
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Check-ins</p>
                  </div>
                  <div className="w-px h-8 bg-zinc-800" />
                  <div>
                    <p className="text-2xl font-black italic tracking-tighter">{stats.votes}</p>
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Total Votes</p>
                  </div>
                </div>
              </div>
            </div>
          </HubCard>

          {/* 4. Processing & Results Hub */}
          <HubCard 
            title="Processing & Results" 
            icon={<Settings className="w-5 h-5" />}
            status={isProcessed ? 'complete' : 'pending'}
            isActive={activeSection === 'processing'}
            onClick={() => setActiveSection('processing')}
          >
            <div className="space-y-6">
              <div className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800 space-y-4">
                <h4 className="text-xs font-black uppercase tracking-widest text-zinc-500">Pre-Processing Checklist</h4>
                <div className="space-y-3">
                  <ChecklistItem label="Score is set" checked={hasScore} />
                  <ChecklistItem label="Home Lineup (min. 11)" checked={hasHomeLineup} />
                  <ChecklistItem label="Away Lineup (min. 11)" checked={hasAwayLineup} />
                  <ChecklistItem label="Match Events recorded" checked={hasEvents} />
                  <ChecklistItem label="Match not yet processed" checked={!isProcessed} />
                </div>
              </div>

              {isProcessed ? (
                <div className="space-y-3">
                  <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3">
                    <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                    <div>
                      <p className="text-sm font-bold text-white">Results Processed</p>
                      <p className="text-[10px] text-zinc-500 uppercase tracking-widest">
                        {new Date(fixture.results_processed_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => navigate(`/matches/${id}/result`)}
                      className="bg-zinc-800 text-white font-bold py-4 rounded-2xl text-xs uppercase tracking-widest"
                    >
                      VIEW RESULTS
                    </button>
                    <button 
                      onClick={handleProcessResults}
                      disabled={saving}
                      className="bg-red-500/10 text-red-500 font-bold py-4 rounded-2xl text-xs uppercase tracking-widest border border-red-500/20"
                    >
                      REPROCESS
                    </button>
                  </div>
                </div>
              ) : (
                <button 
                  onClick={() => setShowConfirmProcess(true)}
                  disabled={!canProcess || saving}
                  className={`w-full font-black py-5 rounded-2xl flex items-center justify-center gap-3 transition-all ${
                    canProcess 
                      ? 'bg-blue-500 hover:bg-blue-600 text-white shadow-lg shadow-blue-500/20' 
                      : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
                  }`}
                >
                  {saving ? <Loader2 className="w-6 h-6 animate-spin" /> : <Trophy className="w-6 h-6" />}
                  <span className="uppercase tracking-tighter italic text-lg">PROCESS RESULTS NOW</span>
                </button>
              )}
              
              {!canProcess && !isProcessed && (
                <p className="text-center text-[10px] font-bold text-zinc-600 uppercase tracking-widest">
                  Complete all checklist items to enable processing
                </p>
              )}
            </div>
          </HubCard>
        </div>
      </div>

      {/* Live Goal Modal */}
      <AnimatePresence>
        {showLiveGoalModal && (
          <div className="fixed inset-0 z-[120] flex items-end sm:items-center justify-center p-4 bg-black/90 backdrop-blur-xl">
            <motion.div
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 100 }}
              className="bg-zinc-900 border border-white/10 rounded-[2.5rem] w-full max-w-lg overflow-hidden shadow-2xl relative"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between bg-zinc-950/30">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl ${liveGoalFormType === 'player' ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400'}`}>
                    <Trophy className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black italic uppercase tracking-tighter">
                      {liveGoalFormType === 'player' ? 'Tor Heimteam' : 'Tor Gegner'}
                    </h3>
                    <p className="text-[8px] font-black text-zinc-500 uppercase tracking-widest">
                      {liveGoalTeam === 'home' ? fixture.home_team?.clubs?.name : fixture.away_team?.clubs?.name}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => {
                    setShowLiveGoalModal(false);
                    setIsAddingOpponentGoal(null);
                  }}
                  className="p-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors"
                >
                  <X className="w-5 h-5 text-zinc-400" />
                </button>
              </div>

              <div className="p-6">
                {liveGoalFormType === 'opponent' ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Rückennummer</label>
                        <input 
                          type="text" 
                          placeholder="#"
                          value={opponentJerseyNumber}
                          onChange={(e) => setOpponentJerseyNumber(e.target.value)}
                          className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-xl font-black italic focus:border-emerald-500 outline-none transition-all placeholder:text-zinc-800"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Minute</label>
                        <input 
                          type="text" 
                          placeholder="Min"
                          value={opponentMinute}
                          onChange={(e) => setOpponentMinute(e.target.value)}
                          className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-xl font-black italic focus:border-emerald-500 outline-none transition-all placeholder:text-zinc-800"
                        />
                      </div>
                    </div>

                    <div className="flex flex-col gap-3 pt-2">
                      <button 
                        onClick={() => handleAddOpponentGoal(liveGoalTeam!)}
                        disabled={!opponentMinute || saving}
                        className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-black italic uppercase tracking-tighter py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-[0.98] disabled:opacity-50 text-lg"
                      >
                        {saving ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : 'TOR SPEICHERN'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="relative">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                      <input 
                        type="text"
                        placeholder="Spieler suchen..."
                        value={playerSearchQuery}
                        onChange={(e) => setPlayerSearchQuery(e.target.value)}
                        className="w-full bg-black border border-white/10 rounded-2xl px-12 py-4 text-sm font-bold focus:border-emerald-500 outline-none transition-all"
                      />
                    </div>

                    <div className="max-h-[350px] overflow-y-auto pr-2 custom-scrollbar space-y-2">
                      {(liveGoalTeam === 'home' ? lineup.home : lineup.away).map(entry => {
                        const player = (liveGoalTeam === 'home' ? homePlayers : awayPlayers).find(p => p.id === entry.player_id);
                        if (!player) return null;
                        if (playerSearchQuery && !player.full_name.toLowerCase().includes(playerSearchQuery.toLowerCase())) return null;

                        return (
                          <button
                            key={player.id}
                            onClick={() => {
                              handleAddEvent(player.id, 'goal');
                              setShowLiveGoalModal(false);
                            }}
                            className="w-full flex items-center justify-between p-4 bg-white/5 hover:bg-emerald-500/10 border border-white/5 hover:border-emerald-500/30 rounded-2xl transition-all group active:scale-[0.98]"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-zinc-800 flex items-center justify-center text-[10px] font-black text-zinc-400 group-hover:text-emerald-500 transition-colors">
                                #{entry.jersey_number || '?'}
                              </div>
                              <div className="text-left">
                                <p className="text-[11px] font-black uppercase italic text-white group-hover:text-emerald-400 transition-colors">{player.full_name}</p>
                                <p className="text-[8px] font-bold text-zinc-500 uppercase tracking-widest">{getPositionShort(player.position)}</p>
                              </div>
                            </div>
                            <Plus className="w-4 h-4 text-zinc-700 group-hover:text-emerald-500 transition-colors" />
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Status Modal */}
      <AnimatePresence>
        {statusModal.isOpen && (
          <div className="fixed inset-0 z-[100] flex justify-center p-6 bg-black/80 backdrop-blur-sm overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-zinc-900 border border-white/10 p-8 rounded-3xl max-w-sm w-full text-center space-y-6 my-auto"
            >
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto ${
                statusModal.type === 'success' ? 'bg-emerald-500/20 text-emerald-500' : 'bg-red-500/20 text-red-500'
              }`}>
                {statusModal.type === 'success' ? <CheckCircle2 className="w-8 h-8" /> : <AlertCircle className="w-8 h-8" />}
              </div>
              <div>
                <h3 className="text-xl font-black italic uppercase tracking-tight">{statusModal.title}</h3>
                <p className="text-zinc-400 text-sm mt-2">{statusModal.message}</p>
              </div>
              <button 
                onClick={() => setStatusModal({ ...statusModal, isOpen: false })}
                className="w-full bg-white text-black font-black py-4 rounded-2xl uppercase tracking-widest text-xs"
              >
                CONTINUE
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {showConfirmProcess && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-zinc-900 border border-white/10 p-8 rounded-[2.5rem] max-w-sm w-full space-y-6 relative overflow-hidden"
            >
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-blue-500/10 blur-[100px]" />
              
              <div className="relative z-10 space-y-6">
                <div className="flex items-center justify-between">
                  <div className="p-3 bg-blue-500/10 rounded-2xl">
                    <Trophy className="w-6 h-6 text-blue-500" />
                  </div>
                  <button 
                    onClick={() => setShowConfirmProcess(false)}
                    className="p-2 text-zinc-500 hover:text-white transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-2">
                  <h2 className="text-2xl font-black italic tracking-tighter uppercase text-white">
                    Process Results?
                  </h2>
                  <p className="text-zinc-400 font-medium leading-relaxed">
                    Bist du sicher, dass du die Resultate für dieses Spiel jetzt berechnen möchtest? Dies aktualisiert die Spieler-Ratings und kann nicht rückgängig gemacht werden.
                  </p>
                </div>

                <div className="flex flex-col gap-3">
                  <button
                    onClick={() => {
                      setShowConfirmProcess(false);
                      handleProcessResults();
                    }}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white font-black py-4 rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20"
                  >
                    JETZT BERECHNEN
                  </button>
                  <button
                    onClick={() => setShowConfirmProcess(false)}
                    className="w-full bg-white/5 hover:bg-white/10 text-white font-bold py-4 rounded-2xl transition-all border border-white/5"
                  >
                    ABBRECHEN
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

// Helper Components
const HubCard: React.FC<{ 
  title: string; 
  icon: React.ReactNode; 
  status: 'complete' | 'pending'; 
  isActive: boolean;
  onClick: () => void;
  children: React.ReactNode;
}> = ({ title, icon, status, isActive, onClick, children }) => (
  <div className={`bg-black/40 backdrop-blur-md border rounded-3xl transition-all overflow-hidden ${
    isActive ? 'border-emerald-500/50 ring-1 ring-emerald-500/20' : 'border-white/10'
  }`}>
    <button 
      onClick={onClick}
      className="w-full p-6 flex items-center justify-between group"
    >
      <div className="flex items-center gap-4">
        <div className={`p-3 rounded-2xl transition-colors ${
          isActive ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-500 group-hover:bg-zinc-700'
        }`}>
          {icon}
        </div>
        <div className="text-left">
          <h3 className="text-lg font-black italic uppercase tracking-tight">{title}</h3>
          <div className="flex items-center gap-2">
            <div className={`w-1.5 h-1.5 rounded-full ${status === 'complete' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
            <span className={`text-[10px] font-bold uppercase tracking-widest ${status === 'complete' ? 'text-emerald-500' : 'text-amber-500'}`}>
              {status === 'complete' ? 'DONE' : 'PENDING'}
            </span>
          </div>
        </div>
      </div>
      <ChevronRight className={`w-5 h-5 transition-transform ${isActive ? 'rotate-90 text-emerald-500' : 'text-zinc-700'}`} />
    </button>
    
    <AnimatePresence>
      {isActive && (
        <motion.div 
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="px-6 pb-6"
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  </div>
);

const TeamLineupSelector: React.FC<{
  teamName: string;
  players: any[];
  selectedLineup: LineupEntryState[];
  onToggle: (id: string) => void;
  onUpdateDetail: (id: string, updates: Partial<LineupEntryState>) => void;
  color: 'emerald' | 'blue';
}> = memo(({ teamName, players, selectedLineup, onToggle, onUpdateDetail, color }) => {
  const colorClass = color === 'emerald' ? 'text-emerald-500' : 'text-blue-500';
  const bgClass = color === 'emerald' ? 'bg-emerald-500' : 'bg-blue-500';
  
  return (
    <div className="space-y-4">
      <div className="flex flex-col">
        <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest leading-none mb-1">{teamName}</span>
        <span className={`text-xs font-black uppercase italic ${colorClass}`}>
          {selectedLineup.filter(l => l.lineup_role === 'starter').length}/11 Starters
        </span>
      </div>
      
      <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
        {players.map(player => {
          const entry = selectedLineup.find(l => l.player_id === player.id);
          const isSelected = !!entry;
          
          return (
            <div key={player.id} className="space-y-1">
              <div className={`w-full p-2 rounded-xl border text-left transition-all flex items-center justify-between ${
                isSelected 
                  ? `bg-${color}-500/10 border-${color}-500/30` 
                  : 'bg-zinc-900 border-zinc-800 text-zinc-500'
              }`}>
                <div 
                  className="flex items-center gap-2 flex-1 cursor-pointer"
                  onClick={() => onToggle(player.id)}
                >
                  <div className={`w-6 h-6 rounded flex items-center justify-center transition-all ${
                    isSelected ? `${bgClass} text-black` : 'bg-zinc-800 text-zinc-600'
                  }`}>
                    {isSelected ? <Check className="w-4 h-4" /> : <Plus className="w-3 h-3" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className={`text-[10px] font-bold truncate ${isSelected ? 'text-white' : ''}`}>{player.full_name}</p>
                    <p className="text-[7px] uppercase tracking-widest opacity-60">{getPositionShort(player.position)}</p>
                  </div>
                </div>

                {isSelected && (
                  <div className="flex items-center gap-2">
                    <div className="relative w-10">
                      <input
                        type="text"
                        placeholder="#"
                        value={entry.jersey_number}
                        onChange={(e) => onUpdateDetail(player.id, { jersey_number: e.target.value })}
                        className="w-full h-7 bg-black border border-zinc-700 rounded text-center text-[10px] text-white font-black italic focus:border-emerald-500 outline-none transition-all"
                      />
                    </div>
                    <select
                      value={entry.lineup_role}
                      onChange={(e) => onUpdateDetail(player.id, { lineup_role: e.target.value as 'starter' | 'sub' })}
                      className={`h-7 bg-black border rounded text-[8px] font-black uppercase px-1 outline-none transition-all ${
                        entry.lineup_role === 'starter' ? 'border-emerald-500/50 text-emerald-500' : 'border-zinc-700 text-zinc-500'
                      }`}
                    >
                      <option value="starter">STR</option>
                      <option value="sub">SUB</option>
                    </select>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
});

const ChecklistItem: React.FC<{ label: string; checked: boolean }> = ({ label, checked }) => (
  <div className="flex items-center justify-between">
    <span className={`text-xs font-bold ${checked ? 'text-zinc-400' : 'text-zinc-600'}`}>{label}</span>
    <div className={`w-5 h-5 rounded-lg flex items-center justify-center border transition-all ${
      checked ? 'bg-emerald-500 border-transparent text-black' : 'bg-zinc-800 border-zinc-700 text-transparent'
    }`}>
      <Check className="w-3 h-3" />
    </div>
  </div>
);

const PlayerEventRow: React.FC<{
  player: any;
  events: any[];
  onAdd: (playerId: string, type: string) => void;
  onRemove: (playerId: string, type: string) => void;
}> = ({ player, events, onAdd, onRemove }) => {
  const goalCount = events.filter(e => e.event_type === 'goal').length;
  const hasYellow = events.some(e => e.event_type === 'yellow_card');
  const hasRed = events.some(e => e.event_type === 'red_card');

  return (
    <div className="flex items-center justify-between p-3 bg-zinc-900/40 border border-white/5 rounded-2xl group hover:bg-zinc-900/60 transition-all">
      <div className="flex flex-col">
        <span className="text-xs font-black italic uppercase tracking-tight text-white group-hover:text-emerald-400 transition-colors">{player.full_name}</span>
        <span className="text-[8px] font-bold text-zinc-500 uppercase tracking-widest">{getPositionShort(player.position)}</span>
      </div>
      
      <div className="flex items-center gap-3">
        {/* Goal Controls */}
        <div className="flex items-center gap-1 bg-black/20 p-1 rounded-xl border border-white/5">
          <button 
            onClick={() => onRemove(player.id, 'goal')}
            disabled={goalCount === 0}
            className="w-8 h-8 flex items-center justify-center bg-zinc-800 rounded-lg disabled:opacity-20 active:scale-90 transition-transform"
          >
            <Minus className="w-3 h-3 text-zinc-400" />
          </button>
          <div className="flex items-center gap-1.5 px-2 min-w-[45px] justify-center">
            <span className="text-xs">⚽</span>
            <span className="text-xs font-black italic tabular-nums text-white">{goalCount}</span>
          </div>
          <button 
            onClick={() => onAdd(player.id, 'goal')}
            className="w-8 h-8 flex items-center justify-center bg-emerald-500 text-black rounded-lg active:scale-90 transition-transform shadow-lg shadow-emerald-500/20"
          >
            <Plus className="w-3 h-3" />
          </button>
        </div>

        {/* Yellow Card */}
        <button 
          onClick={() => hasYellow ? onRemove(player.id, 'yellow_card') : onAdd(player.id, 'yellow_card')}
          className={`w-10 h-10 flex items-center justify-center rounded-xl border transition-all active:scale-90 ${
            hasYellow 
              ? 'bg-amber-500 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)]' 
              : 'bg-zinc-800 border-white/5'
          }`}
        >
          <span className={`text-xs ${hasYellow ? 'text-black' : 'text-zinc-500 opacity-40'}`}>🟨</span>
        </button>

        {/* Red Card */}
        <button 
          onClick={() => hasRed ? onRemove(player.id, 'red_card') : onAdd(player.id, 'red_card')}
          className={`w-10 h-10 flex items-center justify-center rounded-xl border transition-all active:scale-90 ${
            hasRed 
              ? 'bg-red-500 border-red-400 shadow-[0_0_15px_rgba(239,68,68,0.3)]' 
              : 'bg-zinc-800 border-white/5'
          }`}
        >
          <span className={`text-xs ${hasRed ? 'text-black' : 'text-zinc-500 opacity-40'}`}>🟥</span>
        </button>
      </div>
    </div>
  );
};

const OpponentGoalSection: React.FC<{
  teamType: 'home' | 'away';
  isAdding: boolean;
  jerseyNumber: string;
  minute: string;
  events: any[];
  onStartAdd: () => void;
  onCancel: () => void;
  onJerseyChange: (val: string) => void;
  onMinuteChange: (val: string) => void;
  onAdd: () => void;
  onRemove: (id: string) => void;
}> = ({ 
  isAdding, 
  jerseyNumber, 
  minute, 
  events, 
  onStartAdd, 
  onCancel, 
  onJerseyChange, 
  onMinuteChange, 
  onAdd, 
  onRemove 
}) => {
  return (
    <div className="pt-2 border-t border-white/5 space-y-3">
      <div className="flex items-center justify-between px-1">
        <h5 className="text-[8px] font-bold text-zinc-600 uppercase tracking-[0.2em]">Opponent Goals</h5>
        {!isAdding && (
          <button 
            onClick={onStartAdd}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all"
          >
            <Plus className="w-3 h-3 text-emerald-500" />
            Add Goal
          </button>
        )}
      </div>

      {isAdding && (
        <motion.div 
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 bg-zinc-900 border border-emerald-500/20 rounded-2xl flex flex-col gap-3"
        >
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[8px] font-black text-zinc-500 uppercase tracking-widest">Jersey #</label>
              <input 
                type="text" 
                placeholder="9"
                value={jerseyNumber}
                onChange={(e) => onJerseyChange(e.target.value)}
                className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-xs font-black italic focus:border-emerald-500 outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[8px] font-black text-zinc-500 uppercase tracking-widest">Minute</label>
              <input 
                type="text" 
                placeholder="45"
                value={minute}
                onChange={(e) => onMinuteChange(e.target.value)}
                className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-xs font-black italic focus:border-emerald-500 outline-none"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={onCancel}
              className="flex-1 py-2 bg-zinc-800 text-[9px] font-black uppercase tracking-widest rounded-xl hover:bg-zinc-700"
            >
              Cancel
            </button>
            <button 
              onClick={onAdd}
              disabled={!minute}
              className="flex-1 py-2 bg-emerald-500 text-black text-[9px] font-black uppercase tracking-widest rounded-xl hover:bg-emerald-400 disabled:opacity-50"
            >
              Confirm
            </button>
          </div>
        </motion.div>
      )}

      {events.length > 0 && (
        <div className="grid grid-cols-1 gap-2">
          {events.map(event => (
            <div key={event.id} className="flex items-center justify-between p-2 bg-zinc-950 rounded-xl border border-white/5">
              <div className="flex items-center gap-2">
                <span className="text-[10px]">⚽</span>
                <span className="text-[9px] font-black italic text-zinc-400">{event.minute}'</span>
                <span className="text-[10px] font-black italic uppercase text-zinc-200">Tor Gegner #{event.opponent_jersey_number || '?'}</span>
              </div>
              <button 
                onClick={() => onRemove(event.id)}
                className="p-1.5 hover:bg-red-500/10 rounded-lg group transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5 text-zinc-700 group-hover:text-red-500" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminMatchControl;
